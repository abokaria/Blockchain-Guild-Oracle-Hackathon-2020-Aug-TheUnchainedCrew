/**
*Copyright (c) 2020, Oracle and/or its affiliates. All rights reserved.
*/
'use strict';
const shim = require('fabric-shim');
const util = require('util');

var Chaincode = class {
    
    
    // Initialize the chaincode
    async Init(stub) {
        console.info('========= Chaincode initialized =========');
        let ret = stub.getFunctionAndParameters();
        console.info(ret);
        return shim.success();
    }

    async Invoke(stub) {
        console.info('Transaction ID: ' + stub.getTxID());
        let ret = stub.getFunctionAndParameters();
        console.info(ret);
        let method = this[ret.fcn];
        if (!method) {
            console.error('no method of name:' + ret.fcn + ' found');
            throw new Error('Received unknown function ' + ret.fcn + ' invocation');
        }

        console.info('\nCalling method : ' + ret.fcn);
        try {
            let payload = await method(stub, ret.params, this);
            return shim.success(payload);
        } catch (err) {
            console.log(err);
            return shim.error(err);
        }
    }

    // =======================================================================
    // initOrder - create a new order, store into chaincode state
    // =======================================================================
    async initOrder(stub, args, thisClass) {
        //  expects following arguements
        //       0               1                      2               3           4           5           6
        // "healthOfficialId", "manufacturerId", "distributerId", "orderNumber", "product", "orderQty", "orderQtyUnit"
        let order = {};
        let jsonResp = {};
        order.orderStatus = 'Created';
        order.docType = 'PurchaseOrder';
        if (args.length != 7) {
            throw new Error('Incorrect number of arguments. Expecting 7');
        }

        console.info('- start init order');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        if (args[3].length <= 0) {
            throw new Error('4th argument must be a non-empty string');
        }
        if (args[4].length <= 0) {
            throw new Error('5th argument must be a non-empty string');
        }
        if (args[5].length <= 0) {
            throw new Error('6th argument must be a non-empty string');
        }
        if (args[6].length <= 0) {
            throw new Error('7th argument must be a non-empty string');
        }
       
        order.healthOfficialId = args[0];
        order.manufacturerId = args[1];
        order.distributerId = args[2];
        order.orderNumber = args[3];
        order.product = args[4]
        order.orderQty = parseInt(args[5]);
        if(typeof order.orderQty !== 'number'){
            throw new Error('6th argument must be a numeric string');        
        }
        order.orderQtyUnit = args[6];
        order.invoiceAmount = "" ;//args[9]
        order.location = '';
        order.temperature = '';
        order.delivery = '';
        order.deliveryStatus = '';
        order.HUNumber = '';
        order.shipperId = '';
        order.HUStatus = '';
        order.amountPaid = '';
        
        
        
        // ==== Create Order object and marshal to JSON ====    
        let orderJSONasBytes = Buffer.from(JSON.stringify(order));
        
        // === Save Order to state ===
        console.info('Save order:', JSON.stringify(order));
        
        // Write the states back to the ledger
        await stub.putState(order.orderNumber, orderJSONasBytes);
        
        console.info('- end initOrder(success)');
    }

    // ============================================================
    // shipOrder - Updated Statuses 
    // ============================================================
    async shipOrder(stub, args, thisClass) {
        //  expects following arguements
        //       0          
        // "orderNumber"
        let jsonResp = {};
        
        if (args.length != 1) {
            throw new Error('Incorrect number of arguments. Expecting 1');
        }

        console.info('- start shipOrder');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
       
        orderDetail.orderStatus = "Delivery In Transit";
        orderDetail.HUStatus = "In Transit";
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Save Order Details:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end shipOrder');    
    }
    
    // ============================================================
    // assignShipper - Updated Statuses 
    // ============================================================
    async assignShipper(stub, args, thisClass) {
        //  expects following arguements
        //       0             1            2
        // "orderNumber", "shipperId", "delivery"
        let jsonResp = {};
        
        if (args.length != 3) {
            throw new Error('Incorrect number of arguments. Expecting 3');
        }

        console.info('- start shipOrder');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
       
        orderDetail.shipperId = args[1];
        orderDetail.delivery = args[2]
        orderDetail.deliveryStatus = "Shipper Assigned";
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Save Order Details:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end shipOrder');    
    }
    
    // ============================================================
    // assignDelivery - Create Delivery and Assign
    // ============================================================
    async assignDelivery(stub, args, thisClass) {
        //  expects following arguements
        //       0             1          2
        // "orderNumber", "delivery", "HUNumber"
        let jsonResp = {};
        
        if (args.length != 4) {
            throw new Error('Incorrect number of arguments. Expecting 4');
        }

        console.info('- start assignDelivery');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        if (args[3].length <= 0) {
            throw new Error('4th argument must be a non-empty string');
        }
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
       
        orderDetail.delivery = args[1];
        order.HUNumber = args[2]
        orderDetail.orderStatus = "Delivery Assigned";
        orderDetail.HUStatus = "Assigned to Delivery";
        orderDetail.deliveryStatus = "Delivery Created";
        orderDetail.docType = 'DeliveryDoc';
        orderDetail.invoiceAmount = args[3];
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Delivery Assigned:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end assignDelivery');     
    }
    
    
     // ============================================================
    // setOrderTemperature & Location - sets temperatutre and location for shipment tracking
    // ============================================================
    async setOrderTempLoc(stub, args, thisClass) {
         //  expects following arguements
        //       0             1          2
        // "orderNumber", "location", "temperature"
        let jsonResp = {};
        
        if (args.length != 3) {
            throw new Error('Incorrect number of arguments. Expecting 3');
        }

        console.info('- start setOrderTempLoc');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
        orderDetail.location = args[1];
        orderDetail.temperature = args[2];
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Save Order Details:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end setOrderTempLoc');    
    }
    // ============================================================
    // recieveOrder - update status
    // ============================================================
    async recieveOrder(stub, args, thisClass) {
         //  expects following arguements
        //       0             1          2
        // "orderNumber", "location", "temperature"
        let jsonResp = {};
        
        if (args.length != 3) {
            throw new Error('Incorrect number of arguments. Expecting 3');
        }

        console.info('- start recieveOrder');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
       }
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
        orderDetail.location = args[1];
        orderDetail.temperature = args[2];
        orderDetail.orderStatus = "Delivery Recieved";
        orderDetail.HUStatus = "Recieved by Dist";
        orderDetail.deliveryStatus = "Goods Recieved";
        orderDetail.docType = 'goodsReciept';
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Save Order Details:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end recieveOrder');    
    }
    
     // ============================================================
    // updatePayment - Update Payment Stasuses
    // ============================================================
    async updatePayment(stub, args, thisClass) {
        //  expects following arguements
        //       0             1            2             3
        // "orderNumber", "location", "temperature", "amountPaid"
        let jsonResp = {};
        
        if (args.length != 4) {
            throw new Error('Incorrect number of arguments. Expecting 4');
        }

        console.info('- start updatePayment');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        if (args[3].length <= 0) {
            throw new Error('4th argument must be a non-empty string');
        }
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
        orderDetail.location = args[1];
        orderDetail.temperature = args[2];
        orderDetail.orderStatus = "Payment Confirmed";
        orderDetail.deliveryStatus = "Invoice Confirmed";
        orderDetail.docType = 'Invoice Paid';
        orderDetail.amountPaid = args[3]
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Save Order Details:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end updatePayment');    
    }
    
     // ============================================================
    // updateScrap - In case HU in Shipment reaches below the temperature threshold
    //               it will be marked as scrap
    // ============================================================
    async updateScrap(stub, args, thisClass) {
        //  expects following arguements
        //       0             1            2      
        // "orderNumber", "location", "temperature"
        let jsonResp = {};
        
        if (args.length != 3) {
            throw new Error('Incorrect number of arguments. Expecting 3');
        }

        console.info('- start updateScrap');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        let orderNumber = args[0];

        // ==== Check if order number already exists ====
        let orderDetailsAsBytes = await stub.getState(orderNumber);
        if (!orderDetailsAsBytes.toString()){
            console.info('Failed to get order details for: ' + orderNumber);
            jsonResp.Error = 'Failed to get order details for: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let orderDetail = {};
        try{
            orderDetail = JSON.parse(orderDetailsAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + orderNumber;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
        orderDetail.location = args[1];
        orderDetail.temperature = args[2];
        orderDetail.orderStatus = "Scrapped";
        orderDetail.deliveryStatus = "Scrapped";
        orderDetail.docType = 'Scrapped';
        
        // ==== Create order object and marshal to JSON ====
        let orderDetailJSONasBytes = Buffer.from(JSON.stringify(orderDetail));

        console.info('Save Order Details:', JSON.stringify(orderDetail));
        // Write the states back to the ledger
        await stub.putState(orderDetail.orderNumber, orderDetailJSONasBytes);
        console.info('- end updateScrap');    
    }
    // ============================================================
    // initNotif - create a new notification , store into chaincode state
    // ============================================================       
    async initNotif(stub, args, thisClass) {  
        //  expects following arguements
        //       0          1            2             3           4        5
        // "notifId", "productName", "startDate", "startTime", "endDate", "endTime"
        let notif = {};
        let jsonResp = {};
        
        notif.type = 'available';
        
        if (args.length != 6) {
            throw new Error('Incorrect number of arguments. Expecting 6');
        }
        
        // ==== Input sanitation ====
        console.info('- start init Notif');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        if (args[3].length <= 0) {
            throw new Error('4th argument must be a non-empty string');
        }
        if (args[4].length <= 0) {
            throw new Error('5th argument must be a non-empty string');
        }
        if (args[5].length <= 0) {
            throw new Error('6th argument must be a non-empty string');
        }                                    
        
        notif.notifId = args[0];
        notif.productName = args[1];
        notif.startDate = args[2];
        notif.startTime = args[3];
        notif.endDate = args[4];
        notif.endTime = args[5];
        notif.slotbookedDate = '';
        notif.slotbookedTime = '';
        
         // ==== Create Order object and marshal to JSON ====    
        let notifJSONasBytes = Buffer.from(JSON.stringify(notif));
        
        // === Save order to state ===
        console.info('Save notif:', JSON.stringify(notif));
        
        // Write the states back to the ledger
        await stub.putState(notif.notifId, notifJSONasBytes);
        
        console.info('- end initOrder(success)');
    }
    
    // ============================================================
    // updateslot - update the slot selected by end customer
    // ============================================================
    async updateslot(stub, args, thisClass) {
        //  expects following arguements
        //       0             1                2             
        // "notifId", "slotbookedDate", "slotbookedTime"
        let jsonResp = {};
        
        if (args.length != 3) {
            throw new Error('Incorrect number of arguments. Expecting 3');
        }

        console.info('- start updateslot');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if (args[2].length <= 0) {
            throw new Error('3rd argument must be a non-empty string');
        }
        
        let notifId = args[0];

        // ==== Check if order number already exists ====
        let notifAsBytes = await stub.getState(notifId);
        if (!notifAsBytes.toString()){
            console.info('Failed to get order details for: ' + notifId);
            jsonResp.Error = 'Failed to get order details for: ' + notifId;
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        //Buffer to object
        let notifDetail = {};
        try{
            notifDetail = JSON.parse(notifAsBytes.toString('utf8'));
        }catch(err){
            jsonResp.Error = 'Failed to decode JSON of: ' + notifId;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // === Update order detail and sync to world state==========
        notifDetail.slotbookedDate = args[1];
        notifDetail.slotbookedTime = args[2];
        
        // ==== Create order object and marshal to JSON ====
        let notifDetailJSONasBytes = Buffer.from(JSON.stringify(notifDetail));

        console.info('Save Notif Details:', JSON.stringify(notifDetail));
        // Write the states back to the ledger
        await stub.putState(notifDetail.notifId, notifDetailJSONasBytes);
        console.info('- end updateslot');    
    }
    
    
    // ============================================================
    // initFeedback - create a new Feedback , store into chaincode state
    // ============================================================       
    async initFeedback(stub, args, thisClass) {
        //  expects following arguements
        //       0             1                          
        // "productName", "comments"  
        let feedback = {};
        let jsonResp = {};
        
        feedback.type = 'feedback';
        
        if (args.length != 2) {
            throw new Error('Incorrect number of arguments. Expecting 2');
        }
        
        // ==== Input sanitation ====
        console.info('- start init Feedback');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
                                           
        
        feedback.productName = args[0];
        feedback.comments = args[1];
        
        
         // ==== Create Order object and marshal to JSON ====    
        let feedbackJSONasBytes = Buffer.from(JSON.stringify(feedback));
        
        // === Save Notification to state ===
        console.info('Save notif:', JSON.stringify(feedback));
        
        // Write the states back to the ledger
        await stub.putState(feedback.productName, feedbackJSONasBytes);
        
        console.info('- end init Feedback)');
    }
    
    // ==========================================================
    // readOrder - read an order from chaincode state
    // ==========================================================
    async readOrder(stub, args, thisClass) {
        //  expects following arguements
        //       0                                     
        // "orderNumber"
        let jsonResp = {};
        if (args.length != 1) {
            throw new Error('Incorrect number of arguments. Expecting order number to query');
        }
        let orderNumber = args[0];
        let orderAsbytes = await stub.getState(orderNumber); //get the order from chaincode state
        
        if (!orderAsbytes.toString()){
            console.info('Failed to get order for : ' + orderNumber);
            jsonResp.Error = 'Failed to get state for ' + orderNumber;        
            throw new Error(JSON.stringify(jsonResp));    
        }
        
        console.info('readOrder Response:', orderAsbytes.toString('utf8'));
        return orderAsbytes;
    }
    
 
    
   
    
    // ===========================================================================================
    // getHistoryForRecord returns the histotical state transitions for a given key of a record
    // ===========================================================================================
    async getHistoryForRecord(stub, args, thisClass) {

        if (args.length < 1) {
            throw new Error("Incorrect number of arguments. Expecting 1");
        }

        let recordKey = args[0];

        console.info("- start getHistoryForRecord: %s\n", recordKey);

        let resultsIterator = await stub.getHistoryForKey(recordKey);
        
        // results is a JSON array containing historic values for the key/value pair
        let results = [];
        while (true){
            let res = await resultsIterator.next();
            let jsonRes = {};
            
            if (res.value && res.value.value.toString()) {
                console.log(res.value.value.toString('utf8'));
                jsonRes.TxId = res.value.tx_id;
                jsonRes.Timestamp = new Date(res.value.timestamp.seconds.low).toString();
                jsonRes.IsDelete = res.value.is_delete.toString();
                try {
                    jsonRes.Value = JSON.parse(res.value.value.toString('utf8'));
                } catch (err) {
                    console.log(err);
                    jsonRes.Value = res.value.value.toString('utf8');
                }
                results.push(jsonRes);
            }
            if(res.done){
                console.info('end of data');
                await resultsIterator.close();
                console.log("- getHistoryForRecord returning:\n", JSON.stringify(results));
                
                return Buffer.from(JSON.stringify(results));
            }
        }
    }
    
};

shim.start(new Chaincode());

